package com.example.exointents;

import android.app.Activity;

public class secondactivity extends Activity {

}
